#/bin/sh

echo "Starting phrase-nets visualization tool ...";

java -classpath ./lib/*:./phrase-nets.jar pn.Main
